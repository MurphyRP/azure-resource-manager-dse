# install-datastax
These are bash scripts to install and configure DataStax Enterprise (DSE) and OpsCenter on Ubuntu.  They are intended to be used by deployment templates for various cloud technologies.  These include AWS CloudFormation, Azure Resource Manager and Google Deployment Manager.
